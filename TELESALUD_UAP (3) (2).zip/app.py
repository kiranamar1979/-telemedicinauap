
from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/registrar', methods=['GET', 'POST'])
def registrar():
    if request.method == 'POST':
        nombre = request.form['nombre']
        sintomas = request.form['sintomas']
        diagnostico = request.form['diagnostico']
        tratamiento = request.form['tratamiento']
        conn = sqlite3.connect('medica.db')
        c = conn.cursor()
        c.execute("INSERT INTO consultas (nombre, sintomas, diagnostico, tratamiento) VALUES (?, ?, ?, ?)", 
                  (nombre, sintomas, diagnostico, tratamiento))
        conn.commit()
        conn.close()
        return redirect('/consultas')
    return render_template('registrar.html')

@app.route('/consultas')
def consultas():
    conn = sqlite3.connect('medica.db')
    c = conn.cursor()
    c.execute("SELECT * FROM consultas")
    consultas = c.fetchall()
    conn.close()
    return render_template('consultas.html', consultas=consultas)

@app.route('/logout')
def logout():
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
